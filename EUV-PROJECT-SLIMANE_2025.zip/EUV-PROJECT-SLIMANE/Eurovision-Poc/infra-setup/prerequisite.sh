#!/bin/bash


echo "=== Eurovision Pipeline Prerequisite Checker ==="
echo

# Function to check if a command exists
check_cmd() {
    command -v "$1" >/dev/null 2>&1
}

# Detect OS
if [ -f /etc/os-release ]; then
    . /etc/os-release
    DISTRO=$ID
    VERSION=$VERSION_ID
    echo "Detected OS: $PRETTY_NAME"
else
    echo "Kan het besturingssysteem niet detecteren."
    exit 1
fi

# Check Python 3
if check_cmd python3; then
    echo "[OK] Python 3 gevonden: $(python3 --version)"
else
    echo "[FOUT] Python 3 is niet geïnstalleerd."
    if [[ "$DISTRO" == "ubuntu" || "$DISTRO" == "debian" ]]; then
        echo "Installeer Python 3 met:"
        echo "  sudo apt update && sudo apt install -y python3 python3-pip"
    elif [[ "$DISTRO" == "centos" || "$DISTRO" == "rhel" || "$DISTRO" == "fedora" ]]; then
        echo "Installeer Python 3 met:"
        echo "  sudo dnf install -y python3 python3-pip"
    else
        echo "Zie de documentatie van jouw distributie voor Python 3 installatie."
    fi
fi

# Check Docker
if check_cmd docker; then
    echo "[OK] Docker gevonden: $(docker --version)"
else
    echo "[FOUT] Docker is niet geïnstalleerd."
    echo "Je kan de officiële Docker installatiescript gebruiken:"
    echo "  curl -fsSL https://get.docker.com -o get-docker.sh"
    echo "  sudo sh get-docker.sh"
    echo "Of volg de handleiding: https://docs.docker.com/engine/install/"
fi

# Check Docker CLI
if check_cmd docker; then
    echo "[OK] Docker CLI gevonden."
else
    echo "[FOUT] Docker CLI ontbreekt."
fi

# Check Docker Compose (v2 plugin)
if docker compose version >/dev/null 2>&1; then
    echo "[OK] Docker Compose (v2 plugin) gevonden: $(docker compose version | head -n1)"
elif check_cmd docker-compose; then
    echo "[WAARSCHUWING] Docker Compose (v1, los commando) gevonden: $(docker-compose --version)"
    echo "Voor nieuwe projecten wordt Docker Compose v2 plugin aanbevolen."
else
    echo "[FOUT] Docker Compose is niet geïnstalleerd."
    if [[ "$DISTRO" == "ubuntu" || "$DISTRO" == "debian" ]]; then
        echo "Installeer Docker Compose plugin met:"
        echo "  sudo apt update && sudo apt install -y docker-compose-plugin"
    elif [[ "$DISTRO" == "centos" || "$DISTRO" == "rhel" || "$DISTRO" == "fedora" ]]; then
        echo "Installeer Docker Compose plugin met:"
        echo "  sudo dnf install -y docker-compose-plugin"
    else
        echo "Zie de documentatie van jouw distributie voor Docker Compose installatie."
    fi
fi

echo
echo "=== Samenvatting ==="
echo "Besturingssysteem: $PRETTY_NAME"
echo "Python 3: $(if check_cmd python3; then echo 'JA'; else echo 'NEE'; fi)"
echo "Docker: $(if check_cmd docker; then echo 'JA'; else echo 'NEE'; fi)"
echo "Docker Compose: $(if docker compose version >/dev/null 2>&1 || check_cmd docker-compose; then echo 'JA'; else echo 'NEE'; fi)"
echo

echo "Volg de bovenstaande instructies om ontbrekende vereisten te installeren."
echo "Na installatie kun je verder met 'python3 setupinfra.py'."


