import os
import subprocess
from datetime import datetime
from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseUpload
import io

# Configuration
SCOPES = ['https://www.googleapis.com/auth/drive']
SERVICE_ACCOUNT_FILE = os.path.expanduser('~/euv_project/credentials.json')  # Chemin fixe
DRIVE_ROOT_NAME = "Eurovision-Cloud-POC"
LOCAL_WORKSPACE = os.path.expanduser('~/euv_project/cloud_setup')

# Vérification des credentials
if not os.path.exists(SERVICE_ACCOUNT_FILE):
    print(f"""
❌ ERREUR CRITIQUE: 
Le fichier credentials.json est introuvable ici :
{SERVICE_ACCOUNT_FILE}

🛠  SOLUTION :
1. Allez dans Google Cloud Console → IAM → Comptes de service
2. Téléchargez les credentials JSON pour le service account
3. Placez le fichier dans : ~/euv_project/
""")
    exit(1)

def get_drive_service():
    """Initialise le service Google Drive"""
    return build(
        'drive', 
        'v3', 
        credentials=service_account.Credentials.from_service_account_file(
            SERVICE_ACCOUNT_FILE, 
            scopes=SCOPES
        )
    )

def create_drive_folder(service, name, parent_id=None):
    """Crée un dossier dans Drive"""
    folder_metadata = {
        'name': name,
        'mimeType': 'application/vnd.google-apps.folder',
        'parents': [parent_id] if parent_id else []
    }
    return service.files().create(body=folder_metadata, fields='id').execute()['id']

def upload_file(service, name, content, parent_id, mime_type='text/plain'):
    """Upload un fichier dans Drive"""
    file_metadata = {'name': name, 'parents': [parent_id]}
    media = MediaIoBaseUpload(io.BytesIO(content.encode()), mimetype=mime_type)
    return service.files().create(
        body=file_metadata,
        media_body=media,
        fields='id'
    ).execute()['id']

def generate_docker_compose(env_vars):
    """Génère le docker-compose.yml"""
    return f"""version: '3.8'

services:
  generator:
    image: python:3.11-slim
    environment:
      - DRIVE_ROOT_ID={env_vars['ROOT_ID']}
      - DRIVE_DATA_ID={env_vars['DATA_ID']}
    volumes:
      - {SERVICE_ACCOUNT_FILE}:/app/credentials.json
    command: >
      sh -c "pip install google-api-python-client pandas && 
             python /app/generate_votes.py"
  
  aggregator:
    image: python:3.11-slim
    depends_on:
      - generator
    environment:
      - DRIVE_DATA_ID={env_vars['DATA_ID']}
    # ... (similaire pour les autres services)
"""

def main():
    # Initialisation
    service = get_drive_service()
    os.makedirs(LOCAL_WORKSPACE, exist_ok=True)
    
    try:
        # Création structure Drive
        root_id = create_drive_folder(service, DRIVE_ROOT_NAME)
        data_id = create_drive_folder(service, "data", root_id)
        code_id = create_drive_folder(service, "code", root_id)

        # Fichiers à uploader
        files_to_create = {
            'code/generate_votes.py': 
                'import os\nfrom googleapiclient.discovery import build\n# ...',
            'code/Dockerfile': 
                'FROM python:3.11-slim\nRUN pip install pandas ...',
            'docker-compose.yml': generate_docker_compose({
                'ROOT_ID': root_id,
                'DATA_ID': data_id
            }),
            '.env': f"DRIVE_ROOT_ID={root_id}\nDRIVE_DATA_ID={data_id}"
        }

        # Upload des fichiers
        uploaded_ids = {}
        for path, content in files_to_create.items():
            folder_id = code_id if path.startswith('code/') else root_id
            file_id = upload_file(
                service,
                os.path.basename(path),
                content,
                folder_id,
                'text/yaml' if path.endswith('.yml') else 'text/plain'
            )
            uploaded_ids[path] = file_id
            print(f"📄 {path} uploadé → ID: {file_id}")

        # Sauvegarde locale des IDs
        with open(f"{LOCAL_WORKSPACE}/drive_ids.txt", 'w') as f:
            f.write(f"Root Folder ID: {root_id}\n")
            f.write(f"Data Folder ID: {data_id}\n")
            for path, fid in uploaded_ids.items():
                f.write(f"{path}: {fid}\n")

        print(f"""
✅ Déploiement réussi !
📁 Dossier racine Drive : {DRIVE_ROOT_NAME} (ID: {root_id})
📝 Fichier de configuration local : {LOCAL_WORKSPACE}/drive_ids.txt

🔄 Pour utiliser l'infrastructure :
1. Placez vos données dans le dossier Drive 'data'
2. Exécutez : docker compose -f {LOCAL_WORKSPACE}/docker-compose.yml up
""")

    except Exception as e:
        print(f"❌ ERREUR: {str(e)}")
        print("Vérifiez que le service account a bien accès à Drive")

if __name__ == "__main__":
    main()
