from googleapiclient.discovery import build
from google.oauth2 import service_account

# Pad naar je service account key file
SERVICE_ACCOUNT_FILE = 'credentials.json'
SCOPES = ['https://www.googleapis.com/auth/drive.metadata.readonly']

def list_folders():
    creds = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=SCOPES)

    service = build('drive', 'v3', credentials=creds)

    try:
        results = service.files().list(
            q="mimeType='application/vnd.google-apps.folder' and trashed=false",
            pageSize=1000,
            fields="files(id, name)",
            includeItemsFromAllDrives=True,
            supportsAllDrives=True
        ).execute()
        items = results.get('files', [])

        if not items:
            print("⚠️ Geen mappen gevonden.")
        else:
            print("📁 Gevonden folders:")
            for item in items:
                print(f" - {item['name']} (ID: {item['id']})")
    except Exception as e:
        print(f"❌ Fout bij ophalen van folders: {e}")

if __name__ == '__main__':
    list_folders()
