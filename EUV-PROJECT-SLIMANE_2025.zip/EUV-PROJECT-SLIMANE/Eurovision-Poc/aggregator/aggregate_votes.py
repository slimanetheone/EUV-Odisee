import os
import json
from pyspark.sql import SparkSession

data_folder = "/data"
output_file = os.path.join(data_folder, "italy_votes_reduced.json")

vote_files = [f for f in os.listdir(data_folder) if f.endswith("_votes.txt")]

if not vote_files:
    print("No vote files found in /data.")
    exit(1)

spark = SparkSession.builder.appName("SongVoteCount").master("local[*]").getOrCreate()
all_results = []

for vote_file in vote_files:
    input_file = os.path.join(data_folder, vote_file)
    print(f"Processing {input_file}...")
    rdd = spark.sparkContext.textFile(input_file)
    mapped = rdd.map(lambda line: line.strip().split(","))                 .map(lambda fields: ((fields[0], fields[2]), 1))  # (country, song)
    reduced = mapped.reduceByKey(lambda a, b: a + b)
    grouped = reduced.map(lambda x: (x[0][0], (x[0][1], x[1])))                      .groupByKey()                      .mapValues(list)
    result = [{
        "country": x[0],
        "votes": [{"song_number": int(song), "count": int(count)} for song, count in x[1]]
    } for x in grouped.collect()]
    all_results.extend(result)

with open(output_file, "w") as f:
    json.dump(all_results, f, indent=4)
print(f"Results have been saved to {output_file}")
spark.stop()
