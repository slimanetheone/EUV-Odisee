import json
import time
import os
from collections import defaultdict

def print_banner(winner_song, winner_votes):
    banner = f"""
[1;33m
╔══════════════════════════════════════════════════════╗
║              🎉 EUROVISION CHAMPION! 🎉             ║
╠══════════════════════════════════════════════════════╣
║         🏆 Overall Winner: Song {winner_song} with {winner_votes} votes        ║
╚══════════════════════════════════════════════════════╝
[0m
"""
    print(banner)

input_file = "/data/italy_votes_reduced.json"
output_file = "/data/italy_ranking.txt"

while not os.path.exists(input_file):
    print(f"Waiting for {input_file}...")
    time.sleep(2)

try:
    with open(input_file, "r") as f:
        data = json.load(f)

    # Aggregate all votes for each song across all countries
    total_votes = defaultdict(int)
    for entry in data:
        for vote in entry["votes"]:
            song_number = vote["song_number"]
            count = vote["count"]
            total_votes[song_number] += count

    # Sort songs by total votes descending
    final_ranking = sorted(total_votes.items(), key=lambda x: -x[1])

    lines = []
    lines.append("\n[1;36mEurovision Overall Vote Ranking:[0m\n")
    for i, (song, votes) in enumerate(final_ranking, 1):
        lines.append(f"{i}. Song {song}: {votes} votes")
    if final_ranking:
        winner_song, winner_votes = final_ranking[0]
        lines.append(f"\n[1;32mOverall Winner: Song {winner_song} with {winner_votes} votes[0m")
        print_banner(winner_song, winner_votes)

    # Print to screen
    print("\n".join(lines))

    # Save to file
    with open(output_file, "w") as f:
        f.write("\n".join(lines))

    print(f"\nRanking saved to {output_file}")

except FileNotFoundError:
    print(f"File '{input_file}' not found.")

except json.JSONDecodeError:
    print(f"Error decoding JSON from '{input_file}'.")
