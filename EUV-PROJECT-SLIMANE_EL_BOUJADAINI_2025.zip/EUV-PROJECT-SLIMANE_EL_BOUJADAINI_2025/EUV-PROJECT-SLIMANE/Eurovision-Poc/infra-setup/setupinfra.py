import os
import subprocess

def write_file_with_prompt(path, content, actions):
    if os.path.exists(path):
        answer = input(f"File '{path}' already exists. Recreate? (y/n): ")
        if answer.lower() != 'y':
            actions.append((path, 'skipped'))
            print(f"Skipped writing {path}")
            return
    with open(path, 'w') as f:
        f.write(content)
    actions.append((path, 'written'))
    print(f"Written {path}")

def docker_image_exists(image_name):
    result = subprocess.run(
        ["docker", "images", "-q", image_name],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )
    return result.stdout.strip() != ""

def prompt_for_image_name(service, default):
    while True:
        image_name = input(f"Enter Docker image name for {service} (default: {default}): ").strip()
        if not image_name:
            image_name = default
        if docker_image_exists(image_name):
            answer = input(f"Image '{image_name}' already exists locally. Enter a new name or press Enter to keep it: ").strip()
            if answer:
                image_name = answer
            else:
                break
        else:
            break
    return image_name

def main():
    # Ask the user for the project folder name
    folder_name = input("Enter the name of the general project folder (default: Euvsong): ").strip()
    if not folder_name:
        folder_name = "Euvsong"

    # Ask if generator should be interactive or automated
    while True:
        mode = input("Should the generator be interactive at runtime? [y/n]: ").strip().lower()
        if mode in ("y", "n"):
            break
        print("Please enter 'y' or 'n'.")
    interactive = (mode == "y")

    # If automated, ask for vote mode now
    vote_mode = "IT"
    if not interactive:
        while True:
            vote_mode = input("Generate data for (IT) Italy only or (ALL) all countries? [IT/ALL]: ").strip().upper()
            if vote_mode in ("IT", "ALL"):
                break
            print("Please enter 'IT' or 'ALL'.")

    project_root = folder_name
    folders = ["data", "generator", "aggregator", "analyzer"]

    # Prompt for image names, checking if they already exist
    generator_image = prompt_for_image_name("generator", "euvsong-generator:latest")
    aggregator_image = prompt_for_image_name("aggregator", "euvsong-aggregator:latest")
    analyzer_image = prompt_for_image_name("analyzer", "euvsong-analyzer:latest")

    # Generator script: supports both interactive and automated
    generate_votes_py = '''import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta
import os

seed_value = 42
max_votes = 100000

np.random.seed(seed_value)
random.seed(seed_value)

num_records_per_country = max_votes

country_mobile_formats = {
    "BE": "+32 4{0:02d} {1:03d} {2:03d}",
    "FR": "+33 6 {0:02d} {1:02d} {2:02d} {3:02d}",
    "DE": "+49 15{0:01d} {1:03d} {2:04d}",
    "CH": "+41 7{0:01d} {1:03d} {2:02d} {3:02d}",
    "IT": "+39 3{0:02d} {1:03d} {2:03d}",
    "ES": "+34 6{0:01d} {1:02d} {2:02d} {3:02d}",
    "MA": "+212 6{0:01d} {1:02d} {2:02d} {3:02d}",
    "UK": "+44 7{0:02d} {1:03d} {2:04d}",
    "SE": "+46 7{0:01d} {1:03d} {2:03d}",
    "PT": "+351 9{0:02d} {1:03d} {2:03d}",
    "NL": "+31 6 {0:02d} {1:03d} {2:03d}"
}

def generate_mobile_number(country_code):
    if country_code == "BE":
        return country_mobile_formats[country_code].format(
            random.randint(70, 99),
            random.randint(100, 999),
            random.randint(100, 999)
        )
    elif country_code == "FR":
        return country_mobile_formats[country_code].format(
            random.randint(0, 99),
            random.randint(0, 99),
            random.randint(0, 99),
            random.randint(0, 99)
        )
    elif country_code == "DE":
        return country_mobile_formats[country_code].format(
            random.randint(0, 9),
            random.randint(100, 999),
            random.randint(1000, 9999)
        )
    elif country_code == "CH":
        return country_mobile_formats[country_code].format(
            random.randint(0, 9),
            random.randint(100, 999),
            random.randint(0, 99),
            random.randint(0, 99)
        )
    elif country_code == "IT":
        return country_mobile_formats[country_code].format(
            random.randint(0, 99),
            random.randint(100, 999),
            random.randint(100, 999)
        )
    elif country_code == "ES":
        return country_mobile_formats[country_code].format(
            random.randint(0, 9),
            random.randint(0, 99),
            random.randint(0, 99),
            random.randint(0, 99)
        )
    elif country_code == "MA":
        return country_mobile_formats[country_code].format(
            random.randint(0, 9),
            random.randint(0, 99),
            random.randint(0, 99),
            random.randint(0, 99)
        )
    elif country_code == "UK":
        return country_mobile_formats[country_code].format(
            random.randint(0, 99),
            random.randint(100, 999),
            random.randint(1000, 9999)
        )
    elif country_code == "SE":
        return country_mobile_formats[country_code].format(
            random.randint(0, 9),
            random.randint(100, 999),
            random.randint(100, 999)
        )
    elif country_code == "PT":
        return country_mobile_formats[country_code].format(
            random.randint(0, 99),
            random.randint(100, 999),
            random.randint(100, 999)
        )
    elif country_code == "NL":
        return country_mobile_formats[country_code].format(
            random.randint(0, 99),
            random.randint(100, 999),
            random.randint(100, 999)
        )

choice = os.environ.get("VOTE_COUNTRY_MODE")
if not choice:
    print("Do you want to generate votes for Italy only or all EU festival countries?")
    choice = input("Type 'IT' for Italy only or 'ALL' for all countries: ").strip().upper()
else:
    choice = choice.strip().upper()

if choice == 'IT':
    selected_countries = ['IT']
elif choice == 'ALL':
    selected_countries = list(country_mobile_formats.keys())
else:
    print("Invalid choice, defaulting to Italy only.")
    selected_countries = ['IT']

current_time = datetime.now()
os.makedirs("/data", exist_ok=True)

for country_code in selected_countries:
    data = {
        "COUNTRY CODE": [],
        "MOBILE NUMBER": [],
        "SONG NUMBER": [],
        "TIMESTAMP": []
    }
    for _ in range(num_records_per_country):
        data["COUNTRY CODE"].append(country_code)
        data["MOBILE NUMBER"].append(generate_mobile_number(country_code))
        data["SONG NUMBER"].append(random.randint(1, 25))
        random_seconds = random.randint(0, 3600)
        timestamp = current_time - timedelta(seconds=random_seconds)
        data["TIMESTAMP"].append(timestamp.strftime('%Y-%m-%dT%H:%M:%S'))
    filename = f"/data/{country_code.lower()}_votes.txt"
    pd.DataFrame(data).to_csv(filename, index=False, header=False)
    print(f"File '{filename}' has been saved.")
'''

    # Aggregator: process all .txt files in /data
    aggregate_votes_py = '''import os
import json
from pyspark.sql import SparkSession

data_folder = "/data"
output_file = os.path.join(data_folder, "italy_votes_reduced.json")

vote_files = [f for f in os.listdir(data_folder) if f.endswith("_votes.txt")]

if not vote_files:
    print("No vote files found in /data.")
    exit(1)

spark = SparkSession.builder.appName("SongVoteCount").master("local[*]").getOrCreate()
all_results = []

for vote_file in vote_files:
    input_file = os.path.join(data_folder, vote_file)
    print(f"Processing {input_file}...")
    rdd = spark.sparkContext.textFile(input_file)
    mapped = rdd.map(lambda line: line.strip().split(",")) \
                .map(lambda fields: ((fields[0], fields[2]), 1))  # (country, song)
    reduced = mapped.reduceByKey(lambda a, b: a + b)
    grouped = reduced.map(lambda x: (x[0][0], (x[0][1], x[1]))) \
                     .groupByKey() \
                     .mapValues(list)
    result = [{
        "country": x[0],
        "votes": [{"song_number": int(song), "count": int(count)} for song, count in x[1]]
    } for x in grouped.collect()]
    all_results.extend(result)

with open(output_file, "w") as f:
    json.dump(all_results, f, indent=4)
print(f"Results have been saved to {output_file}")
spark.stop()
'''

    # Analyzer: only the overall champion, beautiful banner
    final_ranking_py = '''import json
import time
import os
from collections import defaultdict

def print_banner(winner_song, winner_votes):
    banner = f"""
\033[1;33m
╔══════════════════════════════════════════════════════╗
║              🎉 EUROVISION CHAMPION! 🎉             ║
╠══════════════════════════════════════════════════════╣
║         🏆 Overall Winner: Song {winner_song} with {winner_votes} votes        ║
╚══════════════════════════════════════════════════════╝
\033[0m
"""
    print(banner)

input_file = "/data/italy_votes_reduced.json"
output_file = "/data/italy_ranking.txt"

while not os.path.exists(input_file):
    print(f"Waiting for {input_file}...")
    time.sleep(2)

try:
    with open(input_file, "r") as f:
        data = json.load(f)

    # Aggregate all votes for each song across all countries
    total_votes = defaultdict(int)
    for entry in data:
        for vote in entry["votes"]:
            song_number = vote["song_number"]
            count = vote["count"]
            total_votes[song_number] += count

    # Sort songs by total votes descending
    final_ranking = sorted(total_votes.items(), key=lambda x: -x[1])

    lines = []
    lines.append("\\n\033[1;36mEurovision Overall Vote Ranking:\033[0m\\n")
    for i, (song, votes) in enumerate(final_ranking, 1):
        lines.append(f"{i}. Song {song}: {votes} votes")
    if final_ranking:
        winner_song, winner_votes = final_ranking[0]
        lines.append(f"\\n\033[1;32mOverall Winner: Song {winner_song} with {winner_votes} votes\033[0m")
        print_banner(winner_song, winner_votes)

    # Print to screen
    print("\\n".join(lines))

    # Save to file
    with open(output_file, "w") as f:
        f.write("\\n".join(lines))

    print(f"\\nRanking saved to {output_file}")

except FileNotFoundError:
    print(f"File '{input_file}' not found.")

except json.JSONDecodeError:
    print(f"Error decoding JSON from '{input_file}'.")
'''

    dockerfile_generator = '''FROM python:3.11-slim
RUN pip install pandas numpy
WORKDIR /app
COPY generate_votes.py .
CMD ["python", "generate_votes.py"]
'''

    dockerfile_aggregator = '''FROM bitnami/spark:latest
WORKDIR /app
COPY aggregate_votes.py .
CMD ["spark-submit", "aggregate_votes.py"]
'''

    dockerfile_analyzer = '''FROM python:3.11-slim
WORKDIR /app
COPY final_ranking.py .
CMD ["python", "final_ranking.py"]
'''

    # Compose file with user-chosen image names and user-selected vote mode
    generator_service = f'''  generator:
    build:
      context: ./generator
      dockerfile: Dockerfile.generator
    image: {generator_image}
    volumes:
      - ./data:/data
      - ./generator:/app
'''
    if not interactive:
        generator_service += f'''    environment:
      - VOTE_COUNTRY_MODE={vote_mode}
'''
    else:
        generator_service += f'''    stdin_open: true
    tty: true
'''

    docker_compose_yml = f'''services:
{generator_service}
  aggregator:
    build:
      context: ./aggregator
      dockerfile: Dockerfile.aggregator
    image: {aggregator_image}
    depends_on:
      - generator
    volumes:
      - ./data:/data
      - ./aggregator:/app
    healthcheck:
      test: ["CMD", "sh", "-c", "test -f /data/italy_votes_reduced.json"]
      interval: 5s
      timeout: 3s
      retries: 5
      start_period: 10s

  analyzer:
    build:
      context: ./analyzer
      dockerfile: Dockerfile.analyzer
    image: {analyzer_image}
    depends_on:
      aggregator:
        condition: service_completed_successfully
    volumes:
      - ./data:/data
      - ./analyzer:/app
'''

    # Create folders
    for folder in folders:
        os.makedirs(os.path.join(project_root, folder), exist_ok=True)

    # Set permissions on data folder
    data_path = os.path.join(project_root, "data")
    try:
        os.chmod(data_path, 0o777)
        print(f"Set permissions 777 on {data_path}")
    except Exception as e:
        print(f"Warning: Could not set permissions on {data_path}: {e}")

    actions = []

    # Write files with prompt
    write_file_with_prompt(os.path.join(project_root, "generator", "generate_votes.py"), generate_votes_py, actions)
    write_file_with_prompt(os.path.join(project_root, "generator", "Dockerfile.generator"), dockerfile_generator, actions)
    write_file_with_prompt(os.path.join(project_root, "aggregator", "aggregate_votes.py"), aggregate_votes_py, actions)
    write_file_with_prompt(os.path.join(project_root, "aggregator", "Dockerfile.aggregator"), dockerfile_aggregator, actions)
    write_file_with_prompt(os.path.join(project_root, "analyzer", "final_ranking.py"), final_ranking_py, actions)
    write_file_with_prompt(os.path.join(project_root, "analyzer", "Dockerfile.analyzer"), dockerfile_analyzer, actions)
    write_file_with_prompt(os.path.join(project_root, "docker-compose.yml"), docker_compose_yml, actions)

    print("\nSummary of actions:")
    for path, action in actions:
        print(f"{path}: {action}")

    # Build the images using docker compose
    print(f"\nRunning 'docker compose build' in {project_root} ...")
    try:
        subprocess.run(["docker", "compose", "build"], cwd=project_root, check=True)
        print("Docker images built successfully.")
    except Exception as e:
        print(f"Error during docker compose build: {e}")

    print("\nTo run the full pipeline:")
    print(f"  cd {project_root}")
    if interactive:
        print("  docker compose run --rm generator")
        print("  docker compose up aggregator analyzer")
    else:
        print("  docker compose up")

if __name__ == '__main__':
    main()

